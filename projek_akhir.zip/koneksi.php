<?php
$hostname = "localhost"; //hostname
$username = "root"; //username untuk login ke mysql
$password = ""; //password untuk login ke mysql
$database = "newjeans"; //nama database
$konek=new mysqli($hostname,$username,$password, $database);

if ($konek->connect_error)
{
die('Maaf koneksi gagal: '. $connect->connect_error);
}

?>