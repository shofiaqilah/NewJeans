<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous">
    </script>        

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Geo:ital@0;1&family=Jersey+20&family=Noto+Sans:ital,wght@0,100..900;1,100..900&family=Pixelify+Sans:wght@400..700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Tiny5&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">    
    <link rel="stylesheet" href="disc.css">
    
    <title>Discography</title>
    <style>

    </style>
</head>

<body>
    <header>
        <a href="home.php"><img src="newjeans_font.png" width="100px" style="margin: 20px;"></a>
    </header>
    <main>
        <h1>DISCOGRAPHY</h1>

        <?php
        include 'koneksi.php';
        $query=mysqli_query($konek,"select * from discography");
        while($data=mysqli_fetch_array($query))
        {?>
            <table class="table table-borderless">
                <tr>
                    <td>
                        <div class="card" style="width: 18rem;">
                            <img src=<?php echo $data['cover']?> class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $data['disc_name']?></h5>
                                    <p class="card-text">Release date: <?php echo $data['release_date']?></p>
                                </div>
                        </div>
                    </td>
                    <td>
                            <?php echo $data['video']?>
                            <p class="card-text">Title track:  <?php echo $data['title_track']?> </p>
                    </td>
                </tr>
            </table>
       <?php }?>
    </main>
    <footer>
        <div class="container">
            <a href="https://www.youtube.com/@NewJeans_official"><i class="bi bi-youtube h3"></i></a>
            <a href="https://www.instagram.com/newjeans_official?igsh=YXl6MDUzY2c4ZWs4"><i class="bi bi-instagram h3"></i></a>
            <a href="https://x.com/NewJeans_ADOR"><i class="bi bi-twitter-x h3"></i></a>
            <a href="https://open.spotify.com/artist/6HvZYsbFfjnjFrWF950C9d?si=ZMTjoLWzRr6lurUXz4f-8Q"><i class="bi bi-spotify h3"></i></a>
            <a href="https://www.tiktok.com/@newjeans_official?_t=8r87u9T0Vco&_r=1"><i class="bi bi-tiktok h3"></i></a>
        </div>
    </footer>
</body>

</html>