<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
  <link rel="stylesheet" href="members.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <link
    href="https://fonts.googleapis.com/css2?family=Geo:ital@0;1&family=Noto+Sans:ital,wght@0,100..900;1,100..900&family=Pixelify+Sans:wght@400..700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Tiny5&display=swap"
    rel="stylesheet">

  <title>Danielle</title>
  <style>

  </style>
</head>

<body>
  <header>
    <a href="home.php"><img src="newjeans_font.png" width="100px" style="margin: 20px;"></a>
  </header>
  <main>
    <h2>DANIELLE</h2>

    <?php
      include 'koneksi.php';
      $query=mysqli_query($konek,"select * from member WHERE id = 3");
      $data=mysqli_fetch_array($query)
    ?>

    <div class="wrapper">
      <div class="slide">
        <span id="slide1"></span>
        <span id="slide2"></span>
        <span id="slide3"></span>
        <span id="slide4"></span>
        <div class="images">
          <img src=<?php echo $data['img']?>>
          <img src=<?php echo $data['img1']?>>
          <img src=<?php echo $data['img2']?>>
          <img src=<?php echo $data['img3']?>>
        </div>
      </div>

      <!--navigasi-->
      <div class="navigasi">
        <a href="#slide1">1</a>
        <a href="#slide2">2</a>
        <a href="#slide3">3</a>
        <a href="#slide4">4</a>
      </div>

      <!--basic info-->
      <div id="info">
        <h3>Basic Info</h3>
        <table class="table table-borderless">
          <tr>
            <td>
              Name : <?php echo $data['name']?>
            </td>
          </tr>
          <tr>
            <td>
              Stage Name : <?php echo $data['stage_name']?>
            </td>
          </tr>
          <tr>
            <td>
              Born : <?php echo $data['born']?>
            </td>
          </tr>
          <tr>
            <td>
              Zodiac : <?php echo $data['zodiac']?>
            </td>
          </tr>
          <tr>
            <td>
              Nationality : <?php echo $data['nationality']?>
            </td>
          </tr>
          <tr>
            <td>
              Height : <?php echo $data['height']?> cm
            </td>
          </tr>
          <tr>
            <td>
              Blood Type : <?php echo $data['blood_type']?>
            </td>
          </tr>
          <tr>
            <td>
              MBTI : <?php echo $data['mbti']?>
            </td>
          </tr>
          <tr>
            <td>
              Representative Emoji : <?php echo $data['emoji']?>
            </td>
          </tr>
        </table>
      </div>
    </div>
    <div style="padding-bottom: 10px">
        <table class="table table-borderless" id="videos">
          <tr>
            <td> <?php echo $data['cover']?></td>
            <td> <?php echo $data['fancam']?></td>
          </tr>
        </table>
      </div>
  </main>
  <footer>
    <div class="container">
      <a href=""><i class="bi bi-youtube h3"></i></a>
      <a href=""><i class="bi bi-instagram h3"></i></a>
      <a href=""><i class="bi bi-twitter-x h3"></i></a>
      <a href=""><i class="bi bi-spotify h3"></i></a>
    </div>
  </footer>
</body>

</html>