<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Geo:ital@0;1&family=Noto+Sans:ital,wght@0,100..900;1,100..900&family=Pixelify+Sans:wght@400..700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Tiny5&display=swap"
        rel="stylesheet">
    <title>Danielle</title>
    <style>

    </style>
</head>

<body>
    <header>
        <a href="home.php"><img src="newjeans_font.png" width="100px" style="margin: 20px;"></a>
    </header>
    <main>
        <h2>PROFILE</h2>

        <div class="profile">
            <img src="profile1.jpg">
        </div>
        <h2>MEMBERS</h2>
        <div class="member">
            <table>
                <tr>
                    <td><a href="minji.php"><img src="minji.jpg"></a></td>
                    <td><a href="hanni.php"><img src="hanni.jpg"></a></td>
                    <td><a href="danielle.php"><img src="danielle.jpg"></a></td>
                    <td><a href="haerin.php"><img src="haerin.jpg"></a></td>
                    <td><a href="hyein.php"><img src="hyein.jpg"></a></td>
                </tr>
                <tr>
                    <td><a href="minji.php">
                            <p>Minji</p>
                        </a></td>
                    <td><a href="hanni.php">
                            <p>Hanni</p>
                        </a></td>
                    <td><a href="danielle.php">
                            <p>Danielle</p>
                        </a></td>
                    <td><a href="haerin.php">
                            <p>Haerin</p>
                        </a></td>
                    <td><a href="hyein.php">
                            <p>Hyein</p>
                        </a></td>
                </tr>
            </table>
        </div>
    </main>
    <footer>
        <div class="container">
            <a href="https://www.youtube.com/@NewJeans_official"><i class="bi bi-youtube h3"></i></a>
            <a href="https://www.instagram.com/newjeans_official?igsh=YXl6MDUzY2c4ZWs4"><i class="bi bi-instagram h3"></i></a>
            <a href="https://x.com/NewJeans_ADOR"><i class="bi bi-twitter-x h3"></i></a>
            <a href="https://open.spotify.com/artist/6HvZYsbFfjnjFrWF950C9d?si=ZMTjoLWzRr6lurUXz4f-8Q"><i class="bi bi-spotify h3"></i></a>
            <a href="https://www.tiktok.com/@newjeans_official?_t=8r87u9T0Vco&_r=1"><i class="bi bi-tiktok h3"></i></a>
        </div>
    </footer>
</body>

</html>